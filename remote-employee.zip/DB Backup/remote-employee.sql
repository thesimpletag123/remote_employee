-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jan 04, 2022 at 04:22 PM
-- Server version: 10.1.32-MariaDB
-- PHP Version: 7.4.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `remote-employee`
--

-- --------------------------------------------------------

--
-- Table structure for table `countries`
--

CREATE TABLE `countries` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `country_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `country_abbr` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `countries`
--

INSERT INTO `countries` (`id`, `country_name`, `country_abbr`, `created_at`, `updated_at`) VALUES
(1, 'Asia/Kolkata', 'IND', NULL, NULL),
(2, 'America/Mexico_City', 'USA', NULL, NULL),
(3, 'Europe/London', 'ENG', NULL, NULL),
(4, 'Africa/Freetown', 'SA', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `currency_types`
--

CREATE TABLE `currency_types` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `currency_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `currency_abbr` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `currency_origin` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `currency_types`
--

INSERT INTO `currency_types` (`id`, `currency_name`, `currency_abbr`, `currency_origin`, `created_at`, `updated_at`) VALUES
(1, 'Rupee', 'INR', 'India', NULL, NULL),
(2, 'Dollar', 'DLR', 'USA', NULL, NULL),
(3, 'Dinar', 'DNR', 'Arab', NULL, NULL),
(4, 'Euro', 'EUR', 'Austria', NULL, NULL),
(5, 'Yen', 'JPY', 'Japan', NULL, NULL),
(6, 'Egyptian Pound', 'EGP', 'Egypt', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `employees`
--

CREATE TABLE `employees` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` int(11) NOT NULL,
  `full_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `contact_no` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `professional_field` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `skills` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `extra_skills` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `experience_in_month` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `resume` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_verified` varchar(255) COLLATE utf8_unicode_ci DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `employees`
--

INSERT INTO `employees` (`id`, `user_id`, `full_name`, `contact_no`, `professional_field`, `skills`, `extra_skills`, `experience_in_month`, `resume`, `is_verified`, `created_at`, `updated_at`) VALUES
(1, 2, 'Sourav employee', '1234567890', 'Professional 2', 'php,java', 'JS', '27', NULL, '1', '2022-01-01 21:34:04', '2022-01-01 21:34:44'),
(2, 3, 'Sourav employee2', '1234567890', 'Professional 2', 'php,java', 'JS', '27', NULL, '1', '2022-01-01 21:34:04', '2022-01-01 21:34:44'),
(3, 4, 'test', '11234567890', 'Professional 1', 'Web Application,php,Core Java', 'JS', '120', 'http://localhost:8000/uploads/1641298267-done-avatar.png', '1', '2022-01-04 12:10:21', '2022-01-04 12:12:04');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `connection` text COLLATE utf8_unicode_ci NOT NULL,
  `queue` text COLLATE utf8_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `generate_otps`
--

CREATE TABLE `generate_otps` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` int(11) NOT NULL,
  `otp` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `otp_purpose` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `job_posts`
--

CREATE TABLE `job_posts` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `job_title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `required_skills` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `hourly_rate_min` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `hourly_rate_max` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `project_budget` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `project_description` longtext COLLATE utf8_unicode_ci,
  `invoice_attachment` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `other_attachment` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `posted_by_username` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `posted_by_id` int(100) NOT NULL,
  `assigned_to_username` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `assigned_to_id` int(100) DEFAULT NULL,
  `deadline` date DEFAULT NULL,
  `is_project_approved` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `job_posts`
--

INSERT INTO `job_posts` (`id`, `job_title`, `required_skills`, `hourly_rate_min`, `hourly_rate_max`, `project_budget`, `project_description`, `invoice_attachment`, `other_attachment`, `posted_by_username`, `posted_by_id`, `assigned_to_username`, `assigned_to_id`, `deadline`, `is_project_approved`, `created_at`, `updated_at`) VALUES
(2, 'Php Development 2', 'php-JavaScript-Python', '10 INR', '20 INR', '200 INR', 'Need to Develop in php with JavaScript', NULL, NULL, 'Sourav Majumdar', 1, 'Sourav Majumdar', 1, '2022-01-15', 0, '2022-01-01 21:28:41', '2022-01-04 12:08:57'),
(11, 'Php Development 24', 'php-JavaScript', '10 INR', '20 INR', '200 INR', 'Need to Develop in php with JavaScript', NULL, NULL, 'Sourav Majumdar', 1, 'Sourav employee 2', 3, '2022-01-15', 0, '2022-01-01 21:28:41', '2022-01-04 12:16:27'),
(12, 'Php Development 25', 'php-JavaScript', '10 INR', '20 INR', '200 INR', 'Need to Develop in php with JavaScript', NULL, NULL, 'Sourav Majumdar', 1, 'test', 4, '2022-01-15', 0, '2022-01-01 21:28:41', '2022-01-04 16:19:55'),
(13, 'Python Fulltime Project', '-HTML', '12 INR', '25 INR', NULL, 'Need fulltime Python Employee', NULL, NULL, 'Sourav Majumdar', 1, NULL, NULL, NULL, 0, '2022-01-03 13:00:19', '2022-01-03 13:00:19'),
(14, 'HTML development', 'Web Application-JavaScript-CSS', '12 DLR', '20 DLR', NULL, 'Need to Create a HTML of a full project of 20 pages, with Javascript and CSS.', NULL, NULL, 'Sourav Majumdar', 1, NULL, NULL, NULL, 0, '2022-01-03 21:34:07', '2022-01-03 21:34:07');

-- --------------------------------------------------------

--
-- Table structure for table `job_requests`
--

CREATE TABLE `job_requests` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `job_id` int(11) NOT NULL,
  `request_as` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `from_userid` int(11) NOT NULL,
  `from_username` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `to_userid` int(11) NOT NULL,
  `to_username` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `is_accept` tinyint(1) NOT NULL DEFAULT '0',
  `comment` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `job_requests`
--

INSERT INTO `job_requests` (`id`, `job_id`, `request_as`, `from_userid`, `from_username`, `to_userid`, `to_username`, `is_accept`, `comment`, `created_at`, `updated_at`) VALUES
(1, 2, 'employer', 1, 'Sourav Majumdar', 1, 'Sourav Majumdar', 0, NULL, '2022-01-03 10:47:25', '2022-01-04 12:08:57'),
(2, 11, 'employer', 1, 'Sourav Majumdar', 3, 'Sourav employee 2', 0, NULL, '2022-01-04 12:16:03', '2022-01-04 12:16:27'),
(3, 12, 'employer', 1, 'Sourav Majumdar', 4, 'test', 0, NULL, '2022-01-04 16:19:28', '2022-01-04 16:19:55');

-- --------------------------------------------------------

--
-- Table structure for table `job_trackers`
--

CREATE TABLE `job_trackers` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `jobid` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `jobupdate_headline` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `jobupdate_description` longtext COLLATE utf8_unicode_ci NOT NULL,
  `jobupdate_time` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `jobupdate_status` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `job_trackers`
--

INSERT INTO `job_trackers` (`id`, `jobid`, `user_id`, `jobupdate_headline`, `jobupdate_description`, `jobupdate_time`, `jobupdate_status`, `created_at`, `updated_at`) VALUES
(1, 2, 2, 'First part Done', '1.Implemented frontend\r\n2. Implement login functionalities\r\n3. Implement Employee and Employer Functionalities', '22.5', 'active', '2022-01-02 21:02:03', '2022-01-02 21:02:03'),
(2, 2, 2, 'second part Done', '4.Implemented frontend\r\n5. Implement login functionalities\r\n6. Implement Employee and Employer Functionalities', '12.25', 'active', '2022-01-02 21:02:03', '2022-01-02 21:02:03'),
(3, 3, 11, 'HTML implementation done', 'Implementation of html, css and JS is done', '4', 'active', '2022-01-04 12:28:11', '2022-01-04 12:28:11'),
(4, 3, 11, 'test headline 1', 'Test desc 1', '2.5', 'active', '2022-01-04 12:36:34', '2022-01-04 12:36:34'),
(5, 11, 3, 'tEst head 1', 'asd', '0.5', 'active', '2022-01-04 13:27:04', '2022-01-04 13:27:04');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2021_12_09_191438_add_google_id_column', 1),
(5, '2021_12_13_092346_create_currency_types_table', 1),
(6, '2021_12_13_092457_create_skills_table', 1),
(7, '2021_12_13_092538_create_professional_fields_table', 1),
(8, '2021_12_13_092614_create_countries_table', 1),
(9, '2021_12_13_112913_create_job_posts_table', 1),
(10, '2021_12_13_114158_create_employees_table', 1),
(11, '2021_12_14_111044_create_generate_otps_table', 2),
(12, '2021_12_30_020256_create_job_requests_table', 3),
(13, '2022_01_03_015752_create_job_trackers_table', 4);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `professional_fields`
--

CREATE TABLE `professional_fields` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `professional_fields` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `professional_fields_type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `professional_fields`
--

INSERT INTO `professional_fields` (`id`, `professional_fields`, `professional_fields_type`, `created_at`, `updated_at`) VALUES
(1, 'Professional 1', 'professional_fields_type1', NULL, NULL),
(2, 'Professional 2', 'professional_fields_type2', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `skills`
--

CREATE TABLE `skills` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `skill_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `skill_type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `skills`
--

INSERT INTO `skills` (`id`, `skill_name`, `skill_type`, `created_at`, `updated_at`) VALUES
(1, 'Web Application', 'Technical', NULL, NULL),
(2, 'Find Me a Full', 'Others', NULL, NULL),
(3, 'php', 'php', NULL, NULL),
(4, 'Core Java', 'java', NULL, NULL),
(6, 'JavaScript', 'UserDefined', '2022-01-02 12:22:51', '2022-01-02 12:22:51'),
(7, 'Python', 'UserDefined', '2022-01-02 16:36:55', '2022-01-02 16:36:55');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `user_image` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `google_id` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `linkedin_id` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `user_type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `country` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_verified` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `user_image`, `remember_token`, `created_at`, `updated_at`, `google_id`, `linkedin_id`, `user_type`, `country`, `is_verified`) VALUES
(1, 'Sourav Majumdar', 'souravmajumdar2002@gmail.com', NULL, '$2y$10$ToTJ5rmiSHw3HMwxagmNpOIMhWO0GNPayHzL2Lec.pQ0xhA7vvP3e', 'http://localhost:8000/uploads/1641073371-avatar2.png', NULL, '2022-01-01 21:27:37', '2022-01-03 21:34:07', '110461056873550399516', 'ltQwZN4QIx', 'employer', NULL, 1),
(2, 'Sourav employee', 'sourav@skynetonline.info', NULL, '$2y$10$E9.e47BJeZ73OQDjDBGHSuzMkqVZEX8ZqVg2x.lgKNhN5g56h80Gu', 'http://localhost:8000/uploads/1641143291-male1.png', NULL, '2022-01-01 21:34:04', '2022-01-02 17:08:11', NULL, NULL, 'employee', 'Asia/Kolkata', 1),
(3, 'Sourav employee 2', 'sourav@skynetonline.info2', NULL, '$2y$10$E9.e47BJeZ73OQDjDBGHSuzMkqVZEX8ZqVg2x.lgKNhN5g56h80Gu', 'http://localhost:8000/uploads/1641143291-male1.png', NULL, '2022-01-01 21:34:05', '2022-01-02 17:08:11', NULL, NULL, 'employee', 'Asia/Kolkata', 1),
(4, 'test', 'test@test.com', NULL, '$2y$10$n1G.dULFBXeVH4Ss0oHD4OKNm.tskg7rH.Z6a5f7WgIvQBpCIFPFi', 'http://localhost:8000/uploads/1641298342-done-avatar.png', NULL, '2022-01-04 12:10:21', '2022-01-04 12:12:22', NULL, NULL, 'employee', 'America/Mexico_City', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `countries`
--
ALTER TABLE `countries`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `currency_types`
--
ALTER TABLE `currency_types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `employees`
--
ALTER TABLE `employees`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `generate_otps`
--
ALTER TABLE `generate_otps`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `job_posts`
--
ALTER TABLE `job_posts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `job_requests`
--
ALTER TABLE `job_requests`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `job_trackers`
--
ALTER TABLE `job_trackers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `professional_fields`
--
ALTER TABLE `professional_fields`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `skills`
--
ALTER TABLE `skills`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `countries`
--
ALTER TABLE `countries`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `currency_types`
--
ALTER TABLE `currency_types`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `employees`
--
ALTER TABLE `employees`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `generate_otps`
--
ALTER TABLE `generate_otps`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `job_posts`
--
ALTER TABLE `job_posts`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `job_requests`
--
ALTER TABLE `job_requests`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `job_trackers`
--
ALTER TABLE `job_trackers`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `professional_fields`
--
ALTER TABLE `professional_fields`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `skills`
--
ALTER TABLE `skills`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
