
<?php $__env->startSection('title', 'Employer-Profile'); ?>
<?php $__env->startSection('pagecss'); ?>
<style>
div#modal-dashboard-employer {
    margin-top: 6%;
}
.modal-xl {
    max-width: 80%;
}
* {box-sizing: border-box}


</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="modal-dashboard-employer" id="modal-dashboard-employer" tabindex="-1" aria-labelledby="exampleModalLabel" aria-modal="true" role="dialog" style="display: block;">
	<div class="modal-dialog modal-dialog-centered modal-xl">
		<div class="modal-content">

			<div class="modal-body">
<input type="hidden" id="hidden_uid" value="<?php echo e($user->id); ?>">				
				
<?php echo $__env->make('layouts.dashboardheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
				
				
				<div class="employer-dashboard-body">
					<div class="row">
						<div class="col-lg-3 col-md-12 col-sm-12 col-12">
							<ul class="employer-dashboard-menu">
								<li class="tablinks active selected" data-class="part1" onclick="changetab(event, 'current_employee')">Current Jobs</li>
								<li class="tablinks" data-class="part2" onclick="changetab(event, 'new_employee')">All Employees</li>
								<li class="tablinks" data-class="part3" onclick="changetab(event, 'all_invoice')">View all Invoices</li>
							</ul>
							<!--<div class="uplogout"><a href="">Log out</a></div>-->
						</div>
						<div class="col-lg-9 col-md-12 col-sm-12 col-12">
							<div id='current_employee' class="complex part1">
								<h5>Current Jobs</h5>
								
								<?php if(isset($employerposts)): ?>
									<?php $__currentLoopData = $employerposts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employerpost): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<?php
										$newtime = strtotime($employerpost->created_at);
										$date = date('M d, Y',$newtime);
									?>
								<div class="current-employees-box">
									<div class="current-header">
										<div class="row">
											<div class="col-sm-10">
												<div class="dashboard-avatar">
													<?php if($user->user_image == null): ?>
														<img src="<?php echo e(url('assets/images/avtar.png')); ?>" alt="image">
													<?php else: ?>
														<img src="<?php echo e($user->user_image); ?>" alt="image">
													<?php endif; ?>
													<!--<span></span>-->
												</div>
												<div class="dashboard-avatar-data">
													<h4><?php echo e($employerpost->job_title); ?></h4>
													<div><i class="fas fa-clock"></i> <span>Created at : <?php echo e($date); ?></span></div>

												</div>
											</div>
											<div class="col-sm-2">
												<div class="setticon">
													<span><i class="fas fa-ellipsis-h fa-2x"></i></span>
												</div>
											</div>
										</div>
									</div>
									<div class="current-details">
										<div class="row">
											<div class="col-md">
												<?php if(isset($employerpost->project_budget)): ?>
													<span>|Budget : <?php echo e($employerpost->project_budget); ?>|  </span>
												<?php endif; ?>
												<?php if(isset($employerpost->hourly_rate_min)): ?>
													<span>|Rate Per hour:  Min<?php echo e($employerpost->hourly_rate_min); ?> - Max <?php echo e($employerpost->hourly_rate_max); ?>|</span>
												<?php endif; ?>
												<br>
												<br>
												<p><i class="fas fa-align-justify"></i> <?php echo e($employerpost->project_description); ?></p>
												<div class="review">
													<span>Required Skills</span>
													<?php 
														$skills = null;
														if($employerpost->required_skills){
															$skills = explode('-' , $employerpost->required_skills);
														}
													?>
														<?php $__currentLoopData = $skills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
															<br>
															<i class="fas fa-star"></i> <?php echo e($skill); ?>															
														<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
												</div>
											</div>
											<div class="col-md">
												<div class="current-performance">
													<?php if($employerpost->assigned_to_id == null): ?>
													
													<h6>Not assigned yet</h6>
														<div class="btn-group">
															<select id="employeeavailable_assign-<?php echo e($employerpost->id); ?>" name="employeeavailable_assign" class="employeeavailable_assign">
																		<option>--Select to assign--</option>
																<?php if(isset($employeeavailable)): ?>
																	<?php $__currentLoopData = $employeeavailable; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
																		<option value="<?php echo e($emp->user->id); ?>"><?php echo e($emp->user->name); ?></option>
																	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
																<?php else: ?>
																		<option> No Employee Available </option>
																<?php endif; ?>
															</select>
														</div>
													<?php else: ?>
														<h6>Assigned to: </h6>
														<?php echo e($employerpost->assigned_to_username); ?>

														<br>
														<h6>Re-assign to</h6>
														<div class="btn-group">
															<select id="employeeavailable_assign-<?php echo e($employerpost->id); ?>" name="employeeavailable_assign" class="employeeavailable_assign">
																		<option>--Select to assign--</option>
																<?php if(isset($employeeavailable)): ?>
																	<?php $__currentLoopData = $employeeavailable; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
																		<option value="<?php echo e($emp->user->id); ?>"><?php echo e($emp->user->name); ?></option>
																	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
																<?php else: ?>
																		<option> No Employee Available </option>
																<?php endif; ?>
															</select>
														</div>
													<?php endif; ?>
													<!--<div class="progress-modal">
														<div class="pie-wrapper progress-full">
															<span class="label">85<em>%</em></span>
															<div class="pie">
																<div class="left-side half-circle"></div>
																<div class="right-side half-circle"></div>
															</div>  
														</div>
													</div>-->
												</div>
											</div>
											<table>
												<tr><input type="hidden" class="hidden_jobid" value="<?php echo e($employerpost->id); ?>"></tr>
											</table>
											
											<div class="col-md-12 padding-top">
												<a href="<?php echo e(route('editjobview' , $employerpost->id)); ?>" class="btn btn-primary">Edit</a>
												<button id="<?php echo e($employerpost->id); ?>" onClick="reply_click(this.id)" class="btn btn-danger deletejob">Delete</button>
												
												<a href="<?php echo e(route('trackjob' , $employerpost->id)); ?>" class="btn btn-success">Track</a>
											</div>
										</div>
									</div>
								</div>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									<div class="paginate_links"><?php echo e($employerposts->links()); ?></div>
								<?php else: ?>
								
									<div class="dashboard-avatar-data">
										<h4>No jobs Available for you</h4>
										<div><i class="fas fa-map-marker-alt"></i> <span>You are now loggedin as </span> - <span><?php echo e($user->name); ?></span></div>
									</div>
								
								<?php endif; ?>
							</div>
							
							<!-- Tab 2 -->
							<div id='new_employee' class="complex part2" style="display: none;">
								<h5>Employee List</h5>
								
								<?php if(isset($assignedemployee)): ?>
									<?php $__currentLoopData = $assignedemployee; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<?php if($employee->posted_by_id == $user->id): ?>
										
											<?php if($employee->user->user_type == 'employee'): ?>
										<?php
									//echo "1";
											
											
											$newtime = strtotime($employee->user->created_at);
											$date = date('M d, Y',$newtime);
											
											$exp_yr = floor($employee->employee->experience_in_month/12);
											$exp_month = $employee->employee->experience_in_month%12;
											$experience = $exp_yr. ' Year ' . $exp_month. ' Month';
											//$experience = $date;
										?>
									<div class="current-employees-box">
										<div class="current-header">
											<div class="row">
												<div class="col-sm-10">
													<div class="dashboard-avatar">
														<?php if($employee->user->user_image == null): ?>
															<img src="<?php echo e(url('assets/images/avtar.png')); ?>" alt="image">
														<?php else: ?>
															<img src="<?php echo e($employee->user->user_image); ?>" alt="image">
														<?php endif; ?>
														
														<!--<span></span>-->
													</div>
													<div class="dashboard-avatar-data">
														<div class="one-line">
															<h4><?php echo e($employee->job_title); ?></h4>&nbsp; assigned to : &nbsp;<h4><?php echo e($employee->user->name); ?></h4>
														</div>
														<div><i class="fas fa-clock"></i> <span>With us Since : <?php echo e($date); ?></span></div>

													</div>
												</div>
												<div class="col-sm-2">
													<div class="setticon">
														<span><i class="fas fa-ellipsis-h fa-2x"></i></span>
													</div>
												</div>
											</div>
										</div>
										<div class="current-details">
											<div class="row">
												<div class="col-md">
													<h5>About :: &nbsp;<?php echo e($employee->user->name); ?> </h5>
													<p><i class="fas fa-align-justify"></i> Experience : <?php echo e($experience); ?></p>
													<div class="review">
														<span>Key Skills</span>
														<?php 
															$skillsets = null;
															if($employee->employee->skills){
																$skillsets = explode(',' , $employee->employee->skills);
															}
														?>
															<?php $__currentLoopData = $skillsets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
																<br>
																<i class="fas fa-star"></i> <?php echo e($skill); ?>															
															<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
													</div>
												</div>
												<div class="col-md">
													<h5>Assigned Project Name :: &nbsp;<?php echo e($employee->job_title); ?></h5>
													
												</div>
											</div>
										</div>
									</div>
											<?php endif; ?>
										<?php endif; ?>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									
								<?php else: ?>
								
									<div class="dashboard-avatar-data">
										<h4>No jobs Available for you</h4>
										<div><i class="fas fa-map-marker-alt"></i> <span>You are now loggedin as </span> - <span><?php echo e($user->name); ?></span></div>
									</div>
								
								<?php endif; ?>
							</div>
							
							<!-- Tab 3 -->
							<div id='all_invoice' class="complex part3" style="display: none;">
								<?php if(isset($allinvoice)): ?>
									<?php $__currentLoopData = $allinvoice; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<div class="dashboard-avatar-data">
										<h4><?php echo e($invoice->user->name); ?></h4>
										<div><i class="fas fa-map-marker-alt"></i> <span>You are now loggedin as </span> - <span><?php echo e($user->name); ?></span></div>
									</div>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								<?php else: ?>
									<div class="dashboard-avatar-data">
										<h5>No Invoice available</h5>
									</div>
								<?php endif; ?>
							</div>
						</div>
					</div>
				</div>
				
				
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pagescript'); ?>
	<script>
	function changetab(evt, tabName) {
	  // Declare all variables
	  var i, tabcontent, tablinks;

	  // Get all elements with class="tabcontent" and hide them
	  tabcontent = document.getElementsByClassName("complex");
	  for (i = 0; i < tabcontent.length; i++) {
		tabcontent[i].style.display = "none";
	  }

	  // Get all elements with class="tablinks" and remove the class "active"
	  tablinks = document.getElementsByClassName("tablinks");
	  for (i = 0; i < tablinks.length; i++) {
		tablinks[i].className = tablinks[i].className.replace(" active selected", "");
	  }

	  // Show the current tab, and add an "active" class to the link that opened the tab
	  document.getElementById(tabName).style.display = "block";
	  evt.currentTarget.className += " active selected";
	}

	</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\laravel\remote-employee\resources\views/employerdashboard.blade.php ENDPATH**/ ?>