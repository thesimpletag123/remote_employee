
<?php $__env->startSection('title', 'Profile'); ?>
<?php $__env->startSection('pagecss'); ?>
<style>
div#modal-profile-setting {
    margin-top: 6%;
}
.modal-xl {
    max-width: 80%;
}

.padding_none {
	padding-left: 0px;
}
select#emp_skills {
    width: -webkit-fill-available;
    overflow: auto;
	width: -webkit-fill-available;
    overflow: auto;
    border: 1px solid #ced4da;
    border-radius: 5px;
}
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!-- starting modal-profile-setting -->
	<div class="modal-profile-setting" id="modal-profile-setting" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
		<div class="modal-dialog modal-dialog-centered modal-xl">
			<div class="modal-content">
				<div class="modal-body">
					
					<input type="hidden" id="hidden_uid" value="<?php echo e($user->id); ?>">
<?php echo $__env->make('layouts.dashboardheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
					
					<div class="profile-setting-body">
						<div class="row">

	
	
<div class="col-xl-3 col-lg-4 col-md-12 col-sm-12 col-12">
	<div class="main-setting">
		<div class="availability">
			<h6>Name </h6>
			<p><?php echo e($user->name); ?></p>
			
		</div>
		<div class="myskills">
			<h6>My Email</h6>
			<div class="skill-group">
				<p><?php echo e($user->email); ?></p>
			</div>
		</div>

	<hr>
	<?php $i = 1; ?>
		<?php if(isset($alljobslist)): ?>
			<?php $__currentLoopData = $alljobslist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $singlejob): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<?php if($singlejob['posted_by_id'] == $user->id): ?>
					<?php if($i == 1): ?>
						
					<?php endif; ?>
					<div class="mysidebardiv job-show-hide-div" id="job-<?php echo e($singlejob['id']); ?>">
						<b><?php echo e($singlejob['job_title']); ?></b>
						<div class="col-lg-12 custom_div">
							
								<b><label>Description :</label></b><?php echo e($singlejob['project_description']); ?>

							
						</div>
						<div class="col-lg-12 custom_div">
							<?php if($singlejob['assigned_to_username'] != ''): ?>
								<b><label>Assigned to :</label></b><?php echo e($singlejob['assigned_to_username']); ?>

							<?php else: ?>
								<b><label style="color:red;">Not Assigned Yet.</label></b>
							<?php endif; ?>
						</div>
						<div class="col-lg-12 custom_div">
							<b><label>Skill Required:</label></b> <?=str_replace('-', ' , ', $singlejob['required_skills'])?>
						</div>
					</div>
					
				<?php endif; ?>	
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		<?php endif; ?>
	</div>
</div>
							
							<div class="col-xl-9 col-lg-8 col-md-12 col-sm-12 col-12">
								<h5>My Profile</h5>
								<form id="employerprofileupdate" name="employerprofileupdate" method="post" action="<?php echo e(route('employerprofileupdate')); ?>" enctype="multipart/form-data">
								<?php echo csrf_field(); ?>
									<input type="hidden" id="hidden_uid" name="hidden_uid" value="<?php echo e($user->id); ?>">
									<div class="col-auto">
										<div class="col-lg-8 custom_div">
											<label for="name" class="form-label">Name</label>
											<input type="text" class="form-control" id="name" name="name" placeholder="Job Title here" value="<?php echo e($user->name); ?>">
										</div>
										<div class="col-lg-8 custom_div">
										  <label for="email" class="form-label">Email ID</label>
										  <input type="email" class="form-control" id="email" name="email" value="<?php echo e($user->email); ?>" readonly>
										</div>
										<div class="col-lg-8 custom_div">
											<label for="experience" class="form-label">Joined Remote Employee</label>
											<?php
												$monthNum  = $user->created_at->month;
												$dateObj   = DateTime::createFromFormat('!m', $monthNum);
												$monthName = $dateObj->format('F');
												$usersince = $monthName.', '.$user->created_at->year;
											?>
											<input type="text" step=1 class="form-control" value="<?php echo e($usersince); ?>" readonly>
										</div>
										<div class="col-lg-8 custom_div">
											<input type="submit" value="Update Name" class="btn btn-primary">
										</div>
									</div>
									
									
								</form>
								<hr>
								<div class="col-auto mother-jobdiv">
									<?php if(isset($alljobslist)): ?>
										<?php $__currentLoopData = $alljobslist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $singlejob): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<?php if($singlejob['posted_by_id'] == $user->id): ?>
												<?php if($i == 1): ?>
													<h5> Posted Jobs: </h5>
												<?php endif; ?>
												<div class="jobdiv" id="<?php echo e($singlejob['id']); ?>" onClick="show_job_on_click(this.id)">
													<b><?php echo e($singlejob['job_title']); ?></b>
													<div class="col-lg-12 custom_div">
														<?php if($singlejob['assigned_to_username'] != ''): ?>
															<b><label>Assigned to :</label></b><?php echo e($singlejob['assigned_to_username']); ?>

														<?php else: ?>
															<b><label style="color:red;">Not Assigned Yet.</label></b>
														<?php endif; ?>
													</div>
												</div>
												<?php $i++; ?>
											<?php endif; ?>	
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									<?php endif; ?>
									
								</div>
								
							</div>
							
						</div>
						
									
					</div>					
				</div>
			</div>
		</div>
	</div>
	<!-- End modal-profile-setting -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pagescript'); ?>
<script>

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\laravel\remote-employee\resources\views/employer-profile.blade.php ENDPATH**/ ?>