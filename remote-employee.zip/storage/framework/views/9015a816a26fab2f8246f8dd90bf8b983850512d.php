
<?php $__env->startSection('title', 'Track Job'); ?>
<?php $__env->startSection('pagecss'); ?>
<style>
div#modal-profile-setting {
    margin-top: 6%;
}
.modal-xl {
    max-width: 80%;
}

.padding_none {
	padding-left: 0px;
}
select#emp_skills {
    width: -webkit-fill-available;
    overflow: auto;
	width: -webkit-fill-available;
    overflow: auto;
    border: 1px solid #ced4da;
    border-radius: 5px;
}
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!-- starting modal-profile-setting -->
	<div class="modal-profile-setting" id="modal-profile-setting" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
		<div class="modal-dialog modal-dialog-centered modal-xl">
			<div class="modal-content">
				<div class="modal-body">
					
					<input type="hidden" id="hidden_uid" value="<?php echo e($user->id); ?>">
<?php echo $__env->make('layouts.dashboardheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
					
					<div class="profile-setting-body">
						<div class="row">

	
	
<div class="col-xl-3 col-lg-4 col-md-12 col-sm-12 col-12">
	<div class="main-setting">
		<div class="availability">
			<h6>Name </h6>
			<p><?php echo e($user->name); ?></p>
			
		</div>
		<div class="myskills">
			<h6>My Email</h6>
			<div class="skill-group">
				<p><?php echo e($user->email); ?></p>
			</div>
		</div>
		
	
	<hr>
	
		<?php $__currentLoopData = $getjobupdatebyid; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jobupdate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<div class="mysidebardiv comment-show-hide-div" id="comment-<?php echo e($jobupdate->id); ?>">
				<b>By: <?php echo e($jobupdate->user->name); ?></b>
				<div class="col-lg-12 custom_div">
					<b><label>Headline :</label></b><?php echo e($jobupdate->jobupdate_headline); ?>

				</div>
				<div class="col-lg-12 custom_div">
					<b><label>My Work Description:</label></b> <?php echo e($jobupdate->jobupdate_description); ?>

				</div>
				<div class="col-lg-12 custom_div">
					<b><label>Time worked:</label></b> <?php echo e($jobupdate->jobupdate_time); ?>

				</div>			
			</div>
				
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</div>
</div>
							
							<div class="col-xl-9 col-lg-8 col-md-12 col-sm-12 col-12">
								<h5>Track Job</h5>
								<form id="employeetimeupdate" name="employeetimeupdate" method="post" action="<?php echo e(route('employeetimeupdate')); ?>">
								<?php echo csrf_field(); ?>
									<input type="hidden" id="hidden_uid" name="hidden_uid" value="<?php echo e($user->id); ?>">
									<input type="hidden" id="hidden_jobid" name="hidden_jobid" value="<?php echo e($getjobbyid->id); ?>">
									<div class="col-auto">
										<div class="col-lg-8 custom_div">
											<label for="job_title" class="form-label">Job Title</label>
											<input type="text" class="form-control" id="job_title" name="job_title" placeholder="Job Title here" readonly value="<?php echo e($getjobbyid->job_title); ?>">
										</div>
										<div class="col-lg-8 custom_div">
										  <label for="job_desc" class="form-label">Job Description</label>
										  <textarea class="form-control" id="job_desc" name="job_desc" rows="3" readonly><?php echo e($getjobbyid->project_description); ?></textarea>
										</div>
										<div class="col-lg-8 custom_div">
											<div class="col-md-12 padding_none">
												<label for="job_skills" class="form-label">Required Skills:</label>
											</div>
											<?php
												$skill = null;												
												$required_skills = $getjobbyid->required_skills;
												$required_skills_array = [];
												$required_skills_array = explode('-' , $required_skills);
											
											?>
											
												<?php if(is_array($required_skills_array)): ?>													
													<?php $__currentLoopData = $required_skills_array; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
														<br>
														<i class="fas fa-star"></i> <?php echo e($skill); ?>

													<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
												<?php else: ?>
													<option>No Skills required</option>
												<?php endif; ?>                                                        
											
											
										</div>
											<?php 
												$project_budget = $getjobbyid->project_budget;
												$project_rate_min = $getjobbyid->hourly_rate_min;
											?>
										<div class="col-lg-8 custom_div">
											<?php if( $project_budget != null ): ?>													
												<div class="col-md-12">
													<label for="job_budget" class="form-label">Project Budget :</label>
												</div>
												<input type="text" class="form-control" id="job_budget" name="job_budget" placeholder="Project Budget" value="<?php echo e($project_budget); ?>" readonly>
											<?php endif; ?>
												
										</div>
										<div class="col-lg-8 custom_div">
											<?php if( $project_rate_min != null ): ?>
												<div class="col-md-12">
													<label for="job_budget" class="form-label">Project Min. Rate :</label>
												</div>
												<input type="text" class="form-control" id="job_budget" name="job_budget" placeholder="Project Budget" value="<?php echo e($project_rate_min); ?>" readonly>													
											<?php endif; ?>
										</div>
										<div class="col-lg-8 custom_div">
											<label for="job_deadline" class="form-label">Project Deadline</label>
											<input type="date" class="form-control" id="job_deadline" name="job_deadline" placeholder="Project Deadline" readonly value="<?php echo e($getjobbyid->deadline); ?>" readonly>
										</div>
										
										
									</div>
									<hr>
									<div class="col-auto mother-commentdiv">
										<?php
											$totaltime = 0;
										?>
										<?php if(isset($getjobupdatebyid)): ?>
											<h5>Updates about this </h5>
											<?php $__currentLoopData = $getjobupdatebyid; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $update): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<div class="commentdiv" id="<?php echo e($update->id); ?>" onClick="show_comment_on_click(this.id)">
													<div class="col-lg-8 custom_div">											
														Headline : <?php echo e($update->jobupdate_headline); ?>

													</div>
													<div class="col-lg-8 custom_div">
														Time Worked : <?php echo e($update->jobupdate_time); ?> Hours
													</div>
													<?php 
														
														$totaltime = $totaltime + $update->jobupdate_time;
													?>
												</div>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										<?php endif; ?>
											<br>
												Total worked time : <?php echo $totaltime;?> Hours
											
									</div>
								</form>
								<br>
								<div class="col-lg-8 custom_div">
									<a href="<?php echo e(route('employerdashboard')); ?>" class="btn btn-primary">Back to Dashboard</a>
								</div>
							</div>
							
						</div>
						
									
					</div>					
				</div>
			</div>
		</div>
	</div>
	<!-- End modal-profile-setting -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pagescript'); ?>
<script>
$('#job_budget_currency').on('change', function() {
	var job_budget_currency = $('#job_budget_currency').val();
	var job_min_rate_currency = $('#job_min_rate_currency').val();

	if(job_budget_currency != job_min_rate_currency){
		$('#job_min_rate_currency').val(job_budget_currency);
	}
});
$('#job_min_rate_currency').on('change', function() {
	var job_budget_currency = $('#job_budget_currency').val();
	var job_min_rate_currency = $('#job_min_rate_currency').val();

	if(job_budget_currency != job_min_rate_currency){
		$('#job_budget_currency').val(job_min_rate_currency);
	}
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\laravel\remote-employee\resources\views/employertrackjob.blade.php ENDPATH**/ ?>