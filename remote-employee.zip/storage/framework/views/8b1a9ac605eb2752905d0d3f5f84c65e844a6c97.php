<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <!-- for responsive page -->
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
		<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        <link rel="icon" href="<?php echo e(asset('assets/images/logo-icon.png')); ?>">
		<meta name="google-signin-client_id" content="548697632443-e8k8jltgggkl7vqj97iudua56jftqdaf.apps.googleusercontent.com">
        <title><?php echo $__env->yieldContent('title'); ?> || <?php echo e(config('app.name')); ?></title>
        <!-- for animation -->
        <?php echo $__env->make('layouts.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<?php echo $__env->yieldContent('pagecss'); ?>
		
		
    </head>
    <body>
        <!-- starting header -->
        <header>
            <div class="container">
                <div class="row">
                    <div class="col-lg col-sm-3">
                        <a href="<?php echo e(url('/')); ?>"><img src="<?php echo e(asset('assets/images/main-logo.png')); ?>" alt="logo"></a>
                    </div>
                    <div class="col-lg col-sm-9">
                        <div>
							 <?php if(Auth::check()): ?>
								<form>
									<input type="search" placeholder="SEARCH" name="">
								</form>
							<?php endif; ?>
                        </div>
                        <div>
							<?php if(Route::has('login')): ?>
								<div class="top-right links">
									<?php if(auth()->guard()->check()): ?>
										 <?php if( Request::path() == '/' || Request::path() == '/home'): ?>
											<?php if($user->user_type == 'employer'): ?> 
												<a class="home_btn" href="<?php echo e(url('/employerdashboard')); ?>">Dashboard</a>
											<?php elseif($user->user_type == 'employee'): ?>
												<a class="home_btn" href="<?php echo e(url('/dashboard')); ?>">Dashboard</a>
											<?php endif; ?>
										 <?php else: ?>
											 <a class="home_btn" href="<?php echo e(url('/')); ?>">Home</a>
										 <?php endif; ?>
										
										<a class="logout_btn" href="<?php echo e(url('logout')); ?>" onclick="signOut();">Logout</a>
									<?php else: ?>
										<a href="" data-bs-toggle="modal" data-bs-target="#modal-login" class="login_modal_pop_btn">Login</a>

										<?php if(Route::has('register')): ?>
											<a href="" data-bs-toggle="modal" data-bs-target="#modal-register" class="reg_modal_pop_btn">Register</a>
										<?php endif; ?>
									<?php endif; ?>
								</div>
							<?php endif; ?>
                        </div>
                        <!--<div><span><i class="fas fa-th"></i></span></div>-->
                    </div>
                </div>
            </div>
        </header>
        <!-- End header -->
		
		<?php if(Session::get('success')): ?>
			<div class="alert-custom-div">
				<div class="alert alert-success">
				<?php echo e(session::get('success')); ?>

				</div>
			</div>
		<?php endif; ?><?php /**PATH E:\xampp\htdocs\laravel\remote-employee\resources\views/layouts/header.blade.php ENDPATH**/ ?>