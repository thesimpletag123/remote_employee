
<?php $__env->startSection('title', 'Job Update'); ?>
<?php $__env->startSection('pagecss'); ?>
<style>
div#modal-profile-setting {
    margin-top: 6%;
}
.modal-xl {
    max-width: 80%;
}
input#job_max_rate, input#job_min_rate {
    float: right;
    width: 85%;
}
.padding_none {
	padding-left: 0px;
}
select#emp_skills {
    width: -webkit-fill-available;
    overflow: auto;
	width: -webkit-fill-available;
    overflow: auto;
    border: 1px solid #ced4da;
    border-radius: 5px;
}
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!-- starting modal-profile-setting -->
	<div class="modal-profile-setting" id="modal-profile-setting" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
		<div class="modal-dialog modal-dialog-centered modal-xl">
			<div class="modal-content">
				<div class="modal-body">
					
					<input type="hidden" id="hidden_uid" value="<?php echo e($user->id); ?>">
<?php echo $__env->make('layouts.dashboardheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
					
					<div class="profile-setting-body">
						<div class="row">
							<div class="col-xl-3 col-lg-4 col-md-12 col-sm-12 col-12">
								<div class="main-setting">
									<div class="availability">
										<h6>Name </h6>
										<p><?php echo e($user->name); ?></p>
										
									</div>
									<div class="myskills">
										<h6>Email</h6>
										<div class="skill-group">
											<p><?php echo e($user->email); ?></p>
										</div>
									</div>
									
								
								<hr>
									<div class="sidebardatadiv">
										<?php $__currentLoopData = $getjobupdatebyid; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jobupdate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<div class="mysidebardiv">
												<b>By: <?php echo e($jobupdate->user->name); ?></b>
												<div class="col-lg-12 custom_div">
													<b><label>Headline :</label></b><?php echo e($jobupdate->jobupdate_headline); ?>

												</div>
												<div class="col-lg-12 custom_div">
													<b><label>My Work Description:</label></b> <?php echo e($jobupdate->jobupdate_description); ?>

												</div>
												<div class="col-lg-12 custom_div">
													<b><label>Time worked:</label></b> <?php echo e($jobupdate->jobupdate_time); ?> Hour
												</div>			
											</div>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</div>
								</div>
							</div>
							
							<div class="col-xl-9 col-lg-8 col-md-12 col-sm-12 col-12">
								<h5>Update your job</h5>
								<form id="editjobrequest" name="editjobrequest" method="post" action="<?php echo e(route('editjobrequest')); ?>">
								<?php echo csrf_field(); ?>
									<input type="hidden" id="hidden_uid" name="hidden_uid" value="<?php echo e($user->id); ?>">
									<input type="hidden" id="hidden_jobid" name="hidden_jobid" value="<?php echo e($getjobbyid->id); ?>">
									<div class="col-auto">
										<div class="col-lg-8 custom_div">
											<label for="job_title" class="form-label">Job Title</label>
											<input type="text" class="form-control" id="job_title" name="job_title" placeholder="Job Title here" required value="<?php echo e($getjobbyid->job_title); ?>">
										</div>
										<div class="col-lg-8 custom_div">
										  <label for="job_desc" class="form-label">Job Description</label>
										  <textarea class="form-control" id="job_desc" name="job_desc" rows="3" required><?php echo e($getjobbyid->project_description); ?></textarea>
										</div>
										<div class="col-lg-8 custom_div">
											<div class="col-md-12 padding_none">
												<label for="job_skills" class="form-label">Required Skills (Multi-Select)</label>
											</div>
											<?php
												$skill = null;												
												$required_skills = $getjobbyid->required_skills;
												$required_skills_array = [];
												$required_skills_array = explode('-' , $required_skills);
											
											?>
											<select id="emp_skills" name ="emp_skills[]" multiple required>
												<?php if(isset($skills)): ?>													
													<?php $__currentLoopData = $skills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
														<option value="<?php echo e($skill); ?>"  <?php if(in_array($skill, $required_skills_array)){echo "selected";}?>><?php echo e($skill); ?></option>
													<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
												<?php else: ?>
													<option>No Skill Available</option>
												<?php endif; ?>                                                        
											</select>
											
										</div>
										<div class="col-lg-8 custom_div">
											<label for="job_title" class="form-label">Extra Skills</label>
											<input type="text" class="form-control" id="job_extra_skills" name="job_extra_skills" placeholder="Enter if any Extra Skills required">
										</div>
										<div class="col-lg-8 custom_div">
											<div class="adjust-currency">
												<label for="job_budget" class="form-label">Hourly Rate -Maximum</label>
											</div>
											<?php
												$budgetcurrency = null;
												$minratecurrency = null;
												$maxratecurrency = null;
												$budget = null;
												$minrate = null;
												$maxrate = null;
												
												$project_budget = $getjobbyid->project_budget;
												if( $project_budget != null ){
													$project_budget_array = explode(' ' , $project_budget);
													$budget = $project_budget_array[0];
													$budgetcurrency = $project_budget_array[1];
												}
												
												$project_rate_min = $getjobbyid->hourly_rate_min;
												if( $project_rate_min != null ){
													$project_rate_min_array = explode(' ' , $project_rate_min);
													$minrate = $project_rate_min_array[0];
													$minratecurrency = $project_rate_min_array[1];
												}
												
												$project_rate_max = $getjobbyid->hourly_rate_max;
												if( $project_rate_max != null ){
													$project_rate_max_array = explode(' ' , $project_rate_max);
													$maxrate = $project_rate_max_array[0];
													$maxratecurrency = $project_rate_max_array[1];
												}
												
											?>
											<select id="job_max_rate_currency" name ="job_max_rate_currency">
												<?php if(isset($currencies)): ?>													
													<?php $__currentLoopData = $currencies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $currency => $abbr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
														<option value="<?php echo e($currency); ?>" <?php if($currency == $maxratecurrency){echo "selected";}?>><?php echo e($currency); ?></option>
													<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
												<?php else: ?>
													<option>No Currency Available</option>
												<?php endif; ?>                                                        
											</select>
											<input type="number" class="form-control" id="job_max_rate" name="job_max_rate" placeholder="Project Budget" value="<?php echo e($maxrate); ?>">
										</div>
										<div class="col-lg-8 custom_div">
											<div class="col-md-12 padding_none">
												<label for="job_rate" class="form-label">Hourly Rate -Minimum</label>
											</div>
											<select id="job_min_rate_currency" name ="job_min_rate_currency">
												<?php if(isset($currencies)): ?>													
													<?php $__currentLoopData = $currencies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $currency => $abbr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
														<option value="<?php echo e($currency); ?>" <?php if($currency == $minratecurrency){echo "selected";}?>><?php echo e($currency); ?></option>
													<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
												<?php else: ?>
													<option>No Currency Available</option>
												<?php endif; ?>                                                        
											</select>
											<input type="number" class="form-control" id="job_min_rate" name="job_min_rate" placeholder="Hourly Rate -Minimum" value="<?php echo e($minrate); ?>">
										</div>
										<div class="col-lg-8 custom_div">
											<label for="job_deadline" class="form-label">Project Deadline</label>
											<input type="date" class="form-control" id="job_deadline" name="job_deadline" placeholder="Project Deadline" required value="<?php echo e($getjobbyid->deadline); ?>">
										</div>
										
										<div class="col-lg-8 custom_div">
											<button type="submit" class="btn btn-primary">Update this Job</button>
											<button id="<?php echo e($getjobbyid->id); ?>" onClick="reply_click(this.id)" class="btn btn-danger deletejob">Delete this</button>
										</div>
									</div>
								</form>
							</div>
						</div>
					</div>					
				</div>
			</div>
		</div>
	</div>
	<!-- End modal-profile-setting -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pagescript'); ?>
<script>
$('#job_max_rate_currency').on('change', function() {
	var job_max_rate_currency = $('#job_max_rate_currency').val();
	var job_min_rate_currency = $('#job_min_rate_currency').val();

	if(job_max_rate_currency != job_min_rate_currency){
		$('#job_min_rate_currency').val(job_max_rate_currency);
	}
});
$('#job_min_rate_currency').on('change', function() {
	var job_max_rate_currency = $('#job_max_rate_currency').val();
	var job_min_rate_currency = $('#job_min_rate_currency').val();

	if(job_max_rate_currency != job_min_rate_currency){
		$('#job_max_rate_currency').val(job_min_rate_currency);
	}
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\laravel\remote-employee\resources\views/jobpostview.blade.php ENDPATH**/ ?>