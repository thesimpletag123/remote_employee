
<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('pagecss'); ?>
<style>
div#modal-dashboard-employee {
    margin-top: 6%;
}
.modal-xl {
    max-width: 80%;
}
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<!-- starting modal-dashboard-employee -->
	<div class="modal-dashboard-employee" id="modal-dashboard-employee" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
		<div class="modal-dialog modal-dialog-centered modal-xl">
			<div class="modal-content">
				<div class="modal-body">
<input type="hidden" id="hidden_uid" value="<?php echo e($user->id); ?>">				
<?php echo $__env->make('layouts.dashboardheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
					

					<div class="jopboard">
						<h5>Job Board</h5>
						<h6> You have assigned to bellow Jobs</h6>
					
						
						<?php if(isset($alljobslist)): ?>
							<?php $__currentLoopData = $alljobslist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $singlejob): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<?php if($singlejob['assigned_to_id'] == $user->id): ?>
<?php 
//echo 'User Name'.$user->id;
//echo "<br>";
//echo $singlejob['assigned_to_id'];
?>								
									<div class="jopboard-box">
										<div class="row">
											<div class="col-sm-6 col-12">
												<h4><?php echo e($singlejob['job_title']); ?></h4>
											</div>
											<div class="col-sm-6 col-12">
												<?php if(isset($singlejob['assigned_to_username'])): ?>
													<?php if( $singlejob['assigned_to_username'] == $user->name): ?>
														<a href="<?php echo e(route('update_job_by_employee' , $singlejob['id'])); ?>" class="btn btn-primary">Post an Update </a>
													<?php else: ?>
														Assigned to : <?php echo e($singlejob['assigned_to_username']); ?>

													<?php endif; ?>
													
												<?php else: ?>
													<a href="<?php echo e(route('viewjobemployee' , $singlejob['id'])); ?>" class="btn btn-secondary">View this</a>
												<?php endif; ?>
												
												<div class="setticon">
													<span><i class="fas fa-ellipsis-h fa-2x"></i></span>
												</div>
											</div>
											<div class="col-12">
												<h6>Project Brief</h6>
												<p>
												   <i class="fas fa-file-alt fa-2x"></i> 
													<?php echo e($singlejob['project_description']); ?>

												</p>
											</div>
											<div class="col-md-8 col-sm-12 col-12">
											<?php if($singlejob['invoice_attachment']): ?>
												<h6>Invoice Attachment</h6>
												<div><i class="fas fa-paperclip"></i> <a href="<?php echo e($singlejob['invoice_attachment']); ?>" target="_blabk"> View Last Invoice</a></div>
											<?php else: ?>
												<h6>No Invoice available.</h6>
											<?php endif; ?>
											</div>
											<div class="col-md-4 col-sm-12 col-12">
												<h6>Project Deadline</h6>
												<div><i class="fas fa-calendar-week"></i> <span><?php echo e($singlejob['deadline']); ?></span></div>
											</div>
										</div>
									</div>
								
										
								<?php endif; ?>
								
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						
						<?php endif; ?>
					</div>					
				</div>
			</div>
		</div>
	</div>
	<!-- End modal-dashboard-employee -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\laravel\remote-employee\resources\views/dashboard.blade.php ENDPATH**/ ?>