<link rel="stylesheet" href="{{ asset('assets/css/animate.css') }}">
<!-- library for icon -->
<link rel="stylesheet" href="{{ asset('assets/css/all.min.css') }}">
<link rel="stylesheet" href="{{ asset('assets/css/fontawesome.min.css') }}">
<!-- fancybox -->
<link rel="stylesheet" href="{{ asset('assets/css/jquery.fancybox.css') }}">
<!-- swiper slider -->
<link rel="stylesheet" href="{{ asset('assets/css/swiper-bundle.min.css') }}" />
<link rel="stylesheet" href="{{ asset('assets/css/swiper-bundle2.min.css') }}" /> 
<!-- frame work -->
<link rel="stylesheet" href="{{ asset('assets/css/bootstrap.min4.6.css') }}">
<link rel="stylesheet" href="{{ asset('assets/css/bootstrap.min.css') }}">
<!-- style file -->
<link rel="stylesheet" href="{{ asset('assets/css/outdatedbrowser.min.css') }}">
<link rel="stylesheet" href="{{ asset('assets/css/style.css') }}">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.css">
<link href="https://cdn.jsdelivr.net/gh/gitbrent/bootstrap4-toggle@3.6.1/css/bootstrap4-toggle.min.css" rel="stylesheet">